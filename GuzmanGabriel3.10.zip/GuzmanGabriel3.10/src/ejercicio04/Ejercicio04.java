/*
 * Descripción: Guarda y muestra una lista de 20 numeros enteros dadas por el usuario y su suma de numeros pocitivos y negativos
 * Autor: Gabriel Guzmán
 * Fecha: 05/11/2026
 */

package ejercicio04;

import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Ejercicio04 {
	
	public static void main(String[] args) {
		Scanner pedido = new Scanner(System.in);
		
		final int TAMANO = 20;
		
		double numero = 0;
		
		double[] numeros = new double[TAMANO];
		
		for (int i = 0; i < numeros.length; i++) {
			
			System.out.println("-------------");
			System.out.print("Dame un numero: ");
			numero = pedirDouble(pedido);
			
			numeros[i] = numero;
			
		}
		
		System.out.println("-------------");
		System.out.print("Lista de numeros: ");
		
		for (int i = 0; i < numeros.length; i++) {
			
			System.out.print(numeros[i] + ", ");
			
		}
		
		double sumaPositivos = 0;
		double sumaNegativos = 0;
		
		for (int i = 0; i < numeros.length; i++) {
			
			if (numeros[i] > 0) {
				sumaPositivos += numeros[i];
			} else if (numeros[i] < 0) {
				sumaNegativos += numeros[i];
			}
			
		}
		
		System.out.println("\n-------------");
		System.out.print("La suma de todos los numeros positivos es: " + sumaPositivos);
		System.out.println("\n-------------");
		System.out.print("La suma de todos los numeros negativos es: " + sumaNegativos);

	}
	

	
	
	
	//pedirDouble: pide un int al usuario. (int)
	public static double pedirDouble(Scanner pedido) {
		
		double numero = 0;
		
		boolean error = false;
		
		do {
			
			try {
				
				numero = pedido.nextInt();
				error = false;
				
			} catch (InputMismatchException  e) {
				System.out.println("Error: Debe de introducir un numero entero");
				pedido.nextLine();
				error = true;
			}
			
		} while (error);
		
		return numero;
	}

}
